# Juniper Loop Hackathon Pack

Juniper Loop is a same-week AI/Codex hackathon scenario for cross-disciplinary teams in analytics, technology, creative, strategy, and product.

The fictional client is Juniper Loop, an everyday-habits membership app and commerce brand. Juniper Loop helps people build small, sustainable routines through content, guided journeys, community moments, and wellness-adjacent products. The case is intentionally open-ended so teams can define the opportunity they want to pursue.

## Pack Contents

- `01_challenge_brief.md`: participant-facing challenge and flexible demo expectations.
- `02_client_brief.md`: fictional client context, lifecycle growth ambition, audience, and boundaries.
- `03_brand_kit.md`: lightweight brand voice, sample copy, and creative guardrails.
- `04_data_dictionary.md`: schema definitions for all provided synthetic data files.
- `05_working_with_codex.md`: practical team guide for collaborating with Codex, using Git, and maintaining project decisions.
- `templates/`: starter `AGENTS.md`, ADR, and architecture templates teams can adapt in their prototype repos.
- `../outputs/juniper_loop_team_submission_scaffold.pptx`: team presentation scaffold for Monday demos.
- `../brand_assets/`: optional Juniper Loop visual identity kit with logos, CSS tokens, templates, and local image assets.
- `../data/*.csv`: canonical synthetic CRM data for all teams.
- `../outputs/juniper_loop_data_pack.xlsx`: workbook version of the same data.

## Challenge In One Sentence

Use AI/Codex to create something that helps Juniper Loop build more meaningful, sustained customer relationships across the wellness lifecycle.

## Team Goal

Teams should bring a real demo as far as they reasonably can. A strong submission may take the form of an app, agent workflow, data exploration, creative system, lifecycle strategy, campaign concept, internal tool, measurement approach, or any combination that fits the team's idea.

## Optional Brand Assets

Teams may use the Juniper Loop asset kit in `../brand_assets/` as a starting point for prototypes, slides, campaign previews, or UI demos. The kit is intentionally light so teams can extend it while staying aligned to the shared client world.
